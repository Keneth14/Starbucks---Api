﻿namespace Starbaucks.Application;

public class Class1
{

}
